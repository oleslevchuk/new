

// -------jQery
 


// $('button.scrollsomething').on('click', function() {
//   $.smoothScroll({
//     scrollElement: $('div.(l + *'),
//     scrollTarget: '#*'
//   });
//   return false;
// });

// $(document).ready(function(){
// 	$("#menu").on("click","a", function (event) {
// 		//отменяем стандартную обработку нажатия по ссылке
// 		event.preventDefault();

// 		//забираем идентификатор бока с атрибута href
// 		var id  = $(this).attr('href'),

// 		//узнаем высоту от начала страницы до блока на который ссылается якорь
// 			destin = $(id).offset().top;
		
// 		//анимируем переход на расстояние - top за 1500 мс
// 		$('body,html').animate({scrollTop: destin}, 3000);
// 	});
// });